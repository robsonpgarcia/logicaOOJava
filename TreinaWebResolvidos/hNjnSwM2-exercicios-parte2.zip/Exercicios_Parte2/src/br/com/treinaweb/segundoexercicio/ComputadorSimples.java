package br.com.treinaweb.segundoexercicio;

public class ComputadorSimples extends Computador {
	public void jogarPaciencia(){
		System.out.println("Jogando paciencia!");
	}
}

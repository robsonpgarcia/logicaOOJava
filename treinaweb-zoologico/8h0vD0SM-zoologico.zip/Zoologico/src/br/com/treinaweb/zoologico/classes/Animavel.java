package br.com.treinaweb.zoologico.classes;

public interface Animavel {
	
	Boolean ehAdulto();
	void emitirBarulho();
	void morrer();

}
